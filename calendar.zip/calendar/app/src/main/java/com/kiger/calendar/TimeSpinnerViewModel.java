package com.kiger.calendar;

import androidx.lifecycle.ViewModel;

public class TimeSpinnerViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}